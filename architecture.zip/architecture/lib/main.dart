import 'package:flutter/material.dart';
import 'src/app.dart';

void main() => runApp(MyApp());