class OtherGoal{
  final String _email;
  final String _title;
  final String _message;

  OtherGoal(this._email,this._title,this._message);

  String get email => _email;
  String get title => _title;
  String get message => _message;
}